# Especificação de interface

Copie este template para o repositório do produto e preencha cada seção antes da implementação. Campos entre colchetes são instruções do template, não valores de produção.

## Identificação

- ID: [identificador rastreável]
- Produto/rota: [SaaS e rota]
- Requisito de origem: [link/ID]
- Versão do design system: [versão fixada]
- Usuário e tarefa: [quem faz o quê, em qual contexto]
- Fora de escopo: [limites]

## Dados e autorização

| Campo  | Tipo de domínio | Obrigatório | Valor vazio/default | Componente    | Validação | Mensagem          |
| ------ | --------------- | ----------- | ------------------- | ------------- | --------- | ----------------- |
| [nome] | [tipo]          | [sim/não]   | [regra]             | [API pública] | [regra]   | [texto acionável] |

Defina endpoint/operação, schema, permissão, contexto de instância, estratégia de concorrência, idempotência se aplicável, fuso e unidade monetária. Descreva o tratamento de HTML/arquivos quando presentes.

## Interação

Descreva foco inicial, ordem de Tab, campos dependentes, momento da validação, foco após erro/sucesso, ação principal, cancelamento, perda de alterações e atalhos aplicáveis.

## Estados

| Estado                                                                            | Gatilho  | Apresentação            | Ação de recuperação | Foco/anúncio |
| --------------------------------------------------------------------------------- | -------- | ----------------------- | ------------------- | ------------ |
| [inicial/vazio/carregando/inválido/enviando/sucesso/falha/conflito/sem permissão] | [evento] | [componente e conteúdo] | [ação]              | [regra]      |

## Critérios de aceite

Escreva Given/When/Then com comportamento observável. Inclua sucesso, erro, teclado, celular, strings longas e resposta de API. Relacione cada cenário a um teste. Não use “bonito”, “intuitivo” ou “funciona” como critério isolado.

## Plano e tarefas

Liste arquivos, componentes públicos, estado, integração e testes por tarefa. Registre lacunas do DS e decisões arquiteturais. Nenhuma publicação ou alteração de identidade está implícita na implementação da tela.

## Evidências

Registre comandos, versões, resultados, screenshots quando pertinentes e limitações conhecidas. Indique quem validou negócio e acessibilidade assistiva.
