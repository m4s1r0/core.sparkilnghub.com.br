# Verificação da versão 0.2.0

Verificação final em 26/10/2026, Windows, Node.js 24.18.0, npm 11.16.0, Microsoft Edge via Playwright. Resultados referem-se a esta implementação local, não a uma certificação nem à homologação dos SaaS consumidores.

| Verificação                    | Resultado                                       | Cobertura                                                                                                                                                         |
| ------------------------------ | ----------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run build`                | Passou                                          | TypeScript strict, biblioteca ESM/CSS/declarations, catálogo de produção                                                                                          |
| `npm test`                     | 14 testes passaram                              | Contratos de formulários, sanitização, tabela, loading/vazio, paginação, slides ocultos, progresso, listas, alternância e expansão                                |
| `npm run test:e2e`             | 5 jornadas passaram                             | Desktop 1440px e celular 320px, formulários/editor, abas, accordion, foco/modal/drawer, popover/tooltip/toast, ordenação/paginação, carrossel, scrollspy e navbar |
| axe via Playwright             | Sem violações nas páginas e estados verificados | Tags wcag2a, wcag2aa e wcag21aa; inclui modal aberto e conteúdo em 320px                                                                                          |
| `npm run test:package`         | Passou                                          | Exports públicos, declarações, CSS, presença de tokens e build de aplicação consumidora sem CSS do catálogo/plugin Tailwind                                       |
| Auditoria npm após atualização | 0 vulnerabilidades reportadas                   | Árvore instalada na execução; resultado depende da base de avisos e da data                                                                                       |
| Detector de design Impeccable  | Nenhum achado                                   | Análise mecânica dos arquivos de interface                                                                                                                        |

## Ajustes encontrados na verificação

- Corrigido overflow de grade de código em 320px com min-width:0 nos filhos; a página não mascara overflow globalmente.
- Exemplos de código roláveis receberam foco por teclado.
- Navegação móvel fechada usa visibility:hidden para retirar os links da tabulação.
- Link com aparência de botão primário preserva texto branco contra a regra geral de links.
- Tokens públicos emitidos com `@theme static`, inclusive quando não usados no catálogo.
- Entrada de build separada da API de tipos para não gerar import de arquivo CSS inexistente nas declarações.
- Vitest atualizado para remover os avisos de segurança encontrados na instalação inicial.
- Links diretos por hash aguardam montagem/fonte antes de posicionar a seção; sidebar acompanha a posição de leitura.
- Tabela e exemplos de código mantêm rolagem local com acesso por teclado; não há overflow horizontal da página em 320px.
- As sobreposições receberam verificação de foco contido, Escape e restauração de foco; o menu responsivo também fecha por Escape.

## Artefatos e reprodução

As jornadas produzem screenshots em `test-results/catalog-desktop.png`, `catalog-mobile.png`, `content-interactions-desktop.png`, `content-mobile.png` e `content-drawer-mobile.png`. A pasta é ignorada e recriada nos testes. O catálogo compilado fica em `catalog/`; o pacote em `dist/`. Execute `npm run build` antes de `npm run test:package` ou `npm pack`. A distribuição 0.2.0 é `sparkling-hub-design-system-0.2.0.tgz`.

O consumidor de smoke test é `tests/consumer/`. Ele usa apenas o nome público do pacote e seu CSS, sem importar src diretamente. O bundler pode avisar que diretivas `use client` de dependências foram ignoradas e que o bundle do smoke test é grande; trata-se de uma aplicação cliente mínima, sem divisão de chunks. O catálogo principal separa o editor em um chunk. Projetos SSR/RSC devem declarar a fronteira cliente e carregar o editor sem SSR conforme README.md.

## Limites ainda aplicáveis

- Não foram homologados Safari, Firefox, dispositivos físicos ou leitores de tela. Execute essa homologação nas jornadas críticas de cada produto.
- axe e inspeção visual não substituem avaliação assistiva e validação com usuários.
- Não há backend: sucesso, exportação e dados do catálogo são demonstrações. Não há persistência, autorização, isolamento de instâncias ou upload real a validar aqui.
- Sanitização no cliente não substitui sanitização/validação no servidor. A API do produto precisa limitar tamanho de conteúdo e verificar permissões.
- O tema suportado é claro. Não se declara suporte a modo escuro, traduções completas ou todos os padrões possíveis de formulário.
- A correspondência com Bootstrap cobre os componentes e variantes listados em CONTENT.md. Não há compatibilidade de classes/plugins Bootstrap, nem autoplay/swipe do Carousel ou recursos avançados de datagrid.
