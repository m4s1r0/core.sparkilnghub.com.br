# Conteúdo, navegação e interações — 0.2.0

A implementação amplia a biblioteca existente em React, TypeScript e Tailwind. A documentação do Bootstrap 6.0 foi usada para inventário de recursos e semântica; os blocos do Tailblocks fornecem as composições adaptadas. O pacote não depende do CSS, JavaScript ou dos atributos `data-bs-*` do Bootstrap. As interações complexas usam primitivas Radix com estilos Sparkling Hub.

## Correspondência com a referência

Referência consultada em 26/10/2026: a documentação indicada se identifica como Bootstrap **6.0.0-alpha.1**. A API desta biblioteca é própria, tipada e versionada; não promete equivalência com todos os modificadores/opções do Bootstrap.

| Referência Bootstrap                                                       | API Sparkling Hub                               | Cobertura nesta versão                                                                         |
| -------------------------------------------------------------------------- | ----------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| [Reboot](https://getbootstrap.com/docs/6.0/content/reboot/)                | `.sh-theme` e estilos opt-in                    | Tipografia, box sizing, foco e controles sob o tema; sem reset global de terceiros             |
| [Typography](https://getbootstrap.com/docs/6.0/content/typography/)        | Heading, Text, Blockquote, DescriptionList      | Níveis semânticos, tamanhos visuais, texto de apoio, citação e definições                      |
| [Images](https://getbootstrap.com/docs/6.0/content/images/)                | ResponsiveImage, Figure                         | Imagem fluida, thumbnail, proporção, legenda; srcSet/sizes nativos                             |
| [Prose](https://getbootstrap.com/docs/6.0/content/prose/)                  | Prose                                           | Estilos locais para títulos, texto, listas, código, links e elementos inline                   |
| [Tables](https://getbootstrap.com/docs/6.0/content/tables/)                | DataTable<T>                                    | Caption, cabeçalhos, listras, densidade, rolagem local, vazio, loading e contrato de ordenação |
| [Card](https://getbootstrap.com/docs/6.0/components/card/)                 | Card                                            | Título, corpo, mídia e rodapé                                                                  |
| [Avatar](https://getbootstrap.com/docs/6.0/components/avatar/)             | Avatar                                          | Imagem com fallback de iniciais e nome acessível                                               |
| [List group](https://getbootstrap.com/docs/6.0/components/list-group/)     | ListGroup                                       | Itens informativos, links ou ações; ativo e disabled                                           |
| [Breadcrumb](https://getbootstrap.com/docs/6.0/components/breadcrumb/)     | Breadcrumb                                      | Links de ancestrais e página atual textual                                                     |
| [Button group](https://getbootstrap.com/docs/6.0/components/button-group/) | ButtonGroup                                     | Agrupamento rotulado, com Tab nativo                                                           |
| [Toggler](https://getbootstrap.com/docs/6.0/components/toggler/)           | ToggleButton                                    | Alternância controlada com aria-pressed                                                        |
| [Nav](https://getbootstrap.com/docs/6.0/components/nav/)                   | Nav                                             | Links de navegação com página atual                                                            |
| [Nav overflow](https://getbootstrap.com/docs/6.0/components/nav-overflow/) | NavOverflow                                     | Trilho horizontal rolável e focável                                                            |
| [Navbar](https://getbootstrap.com/docs/6.0/components/navbar/)             | Navbar                                          | Marca, links, ação e disclosure responsivo ao contêiner                                        |
| [Pagination](https://getbootstrap.com/docs/6.0/components/pagination/)     | Pagination                                      | Página atual, limites, anterior/próxima e janela com reticências                               |
| [Stepper](https://getbootstrap.com/docs/6.0/components/stepper/)           | Stepper; StepsBlock existente                   | Etapas informativas ou callbacks de navegação, estado atual e concluído                        |
| [Scrollspy](https://getbootstrap.com/docs/6.0/components/scrollspy/)       | ScrollSpyNav, useScrollSpy                      | Acompanha âncoras na janela ou em contêiner rolável                                            |
| [Accordion](https://getbootstrap.com/docs/6.0/components/accordion/)       | Accordion                                       | Expansão única ou múltipla, disabled, controle externo e navegação por teclado                 |
| [Collapse](https://getbootstrap.com/docs/6.0/components/collapse/)         | Collapse                                        | Botão associado ao painel; estado controlado ou interno                                        |
| [Tab](https://getbootstrap.com/docs/6.0/components/tab/)                   | Tabs                                            | Painéis, orientação, setas, Home/End e abas desabilitadas                                      |
| [Dialog](https://getbootstrap.com/docs/6.0/components/dialog/)             | Dialog                                          | Modal com título, descrição, foco contido e retorno do foco                                    |
| [Drawer](https://getbootstrap.com/docs/6.0/components/drawer/)             | Drawer                                          | Mesma semântica modal, nas posições esquerda, direita ou inferior                              |
| [Close button](https://getbootstrap.com/docs/6.0/components/close-button/) | CloseButton                                     | Botão com nome acessível e alvo de 44px                                                        |
| [Popover](https://getbootstrap.com/docs/6.0/components/popover/)           | Popover                                         | Informação interativa contextual com título, fechamento e posicionamento                       |
| [Tooltip](https://getbootstrap.com/docs/6.0/components/tooltip/)           | Tooltip                                         | Ajuda curta ao hover/foco, Escape e associação acessível                                       |
| [Toasts](https://getbootstrap.com/docs/6.0/components/toasts/)             | ToastProvider, Toast                            | Fila visual, anúncio, timeout, pausa na interação e fechamento                                 |
| [Carousel](https://getbootstrap.com/docs/6.0/components/carousel/)         | Carousel                                        | Slides de conteúdo, navegação manual e anúncio da posição; sem autoplay/swipe                  |
| [Placeholder](https://getbootstrap.com/docs/6.0/components/placeholder/)   | Skeleton                                        | Linhas estáticas de carregamento com nome acessível                                            |
| [Progress](https://getbootstrap.com/docs/6.0/components/progress/)         | Progress                                        | Progresso nativo, determinado ou indeterminado                                                 |
| [Spinner](https://getbootstrap.com/docs/6.0/components/spinner/)           | Spinner                                         | Ícone e texto de carregamento, com movimento reduzido                                          |
| Alert, Badge, Button, Menu                                                 | Alert, Badge, Button, DropdownButton existentes | Reutilizados e descritos em COMPONENTS.md                                                      |

Componentes de formulários novos do Bootstrap (combobox, datepicker, OTP etc.) não foram adicionados nesta expansão de conteúdo. As primitivas de formulário da versão anterior permanecem disponíveis.

## Importação e tema

```tsx
import "@sparkling-hub/design-system/styles.css";
import { Card, Heading, Text, Tabs } from "@sparkling-hub/design-system";

<div className="sh-theme">
  <Card title="Atendimento">
    <Text tone="muted">Confira as informações antes de continuar.</Text>
  </Card>
</div>;
```

O pacote entrega CSS compilado. Não exige Tailwind ou Bootstrap no consumidor para que os componentes funcionem. Layout adicional do produto pode usar Tailwind. Portais de Dialog, Drawer, Popover, Tooltip e a viewport de Toast recebem o tema; não dependem de herdar fonte/cores de um ancestral do aplicativo.

## Conteúdo editorial e imagem

- `Heading`: `level?: 1|2|3|4|5|6` (2), `size?: display|section|title|small` (section), atributos nativos de heading. Level controla semântica; size controla aparência. Preserve a hierarquia da página.
- `Text`: `as?: p|span|div` (p), `tone?: default|muted`, `lead?: boolean`, atributos de HTMLElement. Use elementos inline dentro de parágrafos para não criar HTML inválido.
- `Prose`: children React/MDX confiáveis e atributos de div, **excluindo dangerouslySetInnerHTML** da API tipada. Não analisa Markdown, não sanitiza HTML e não é um visualizador direto do editor. Renderizadores de conteúdo armazenado devem cumprir a política de sanitização do produto.
- `Blockquote`: children, `author?`, `source?`. Renderiza figure/blockquote/figcaption/cite. Não invente depoimentos; no catálogo a autoria é demonstrativa.
- `DescriptionList`: `items: {id,term,description}[]`. Usa dl/dt/dd, sem comportamento de formulário.
- `ResponsiveImage`: `alt` obrigatório (string vazia apenas para imagem decorativa), atributos nativos incluindo width/height/srcSet/sizes; `thumbnail?`, `fit?: cover|contain`, `ratio?: square|landscape|portrait|auto`. Loading lazy padrão; use eager/fetchPriority para mídia principal quando necessário.
- `Figure`: propriedades de ResponsiveImage + `caption: ReactNode`; className aplica-se ao figure. Toda imagem gerada/demonstrativa deve ter legenda “Imagem ilustrativa”.
- `Avatar`: `name`, `src?`, `size?: sm|md|lg`. Imagem com falha volta às iniciais; o nome acessível permanece. Não recebe links ou ações.
- `Card`: `title`, children, `media?`, `footer?`, `headingLevel?` (3), atributos de article. O card não é um botão gigante. Mantenha links e botões explícitos nos slots.

## Composições Tailblocks

Dados são fornecidos por propriedades; nenhum componente busca dados ou conhece regras de negócio.

| API            | Propriedades                                                                                       |
| -------------- | -------------------------------------------------------------------------------------------------- |
| ContentSection | title, description?, children, headingLevel? (2), id?                                              |
| HeroBlock      | title, description, actions?, media?, headingLevel? (1). Em páginas que já têm h1, ajuste o nível. |
| FeatureGrid    | items: {id,title,description,icon?,link?:{href,label}}[]. Títulos dos itens são h3.                |
| Gallery        | label, items: {id,src,alt,caption}[]                                                               |
| TeamGrid       | people: {id,name,role,description?,image?}[]; título de pessoa h3                                  |
| PricingGrid    | plans: {id,name,price,description,features:string[],action,highlight?}[]                           |
| CalloutBlock   | title, description?, action                                                                        |
| FooterBlock    | brand, description?, groups: {id,title,links:{href,label}[]}[], legal?                             |

`PricingGrid` é uma estrutura de comparação, não uma fonte de preços/condições. `TeamGrid` não fornece pessoas reais. O catálogo usa exemplos explicitamente rotulados. `Blockquote` e `Card` também derivam de composições Tailblocks. A proveniência completa está em TAILBLOCKS.md.

## Tabela e lista

```tsx
type Contact = { id: string; name: string; product: string };
const columns: TableColumn<Contact>[] = [
  {
    id: "name",
    header: "Contato",
    rowHeader: true,
    sortable: true,
    cell: (row) => row.name,
  },
  { id: "product", header: "Produto", cell: (row) => row.product },
];
<DataTable<Contact>
  caption="Contatos"
  columns={columns}
  rows={rows}
  rowKey={(row) => row.id}
  sort={sort}
  onSort={changeSort}
/>;
```

`DataTable<T>` exige caption, columns, rows e rowKey. Columns: `id`, `header: string`, `cell(row): ReactNode`, `rowHeader?`, `align?: start|end`, `sortable?`. Deve existir ao menos uma coluna; IDs e rowKeys devem ser únicos e estáveis. Opções: `striped?`, `compact?`, `loading?`, `emptyMessage?`, `sort?: {column,direction:asc|desc}`, `onSort?(column)`.

A tabela expõe aria-sort e emite a intenção de ordenar; o consumidor ordena os registros ou consulta a API. Ordenação, filtro e paginação devem operar na mesma coleção; voltar à primeira página após mudar filtro/ordem. `loading` mostra texto de carregamento em vez de lista vazia. A região rolável tem nome e foco por teclado. A rolagem é local; a página não deve ganhar overflow horizontal. Não oferece edição, seleção, virtualização ou agrupamento de linhas nesta versão.

`ListGroup`: label, items e activeId?. Cada item tem id, label, description?, trailing?, disabled? e **um** entre href, onSelect ou nenhum (informativo). Item ativo tem sinal textual além da cor. Link disabled vira texto; botão disabled fica fora da tabulação. Não use itens informativos como ações por onClick na lista.

## Navegação

- `Breadcrumb`: `items:{label,href?}[]`, label?; último item é a página atual e não é link.
- `ButtonGroup`: label, children e atributos de div. Agrupa botões, sem implementar um toolbar/roving tabIndex.
- `ToggleButton`: ButtonProps + `pressed:boolean`, `onPressedChange(boolean)`. Controlado, aria-pressed. Não substitui checkbox de formulário.
- `Nav`/`NavOverflow`: items:{id,label,href}[], label, activeId?, onNavigate?(id). Links reais, não painéis de abas. NavOverflow oferece rolagem horizontal e foco na região.
- `Navbar`: brand, items, label?, activeId?, action?. O menu colapsa de acordo com a largura do **contêiner** (44rem), não só da janela. Escape fecha e devolve foco ao botão. Navegar por link fecha o disclosure. O slot brand deve conter a marca/link apropriado.
- `Pagination`: page (base 1), pageCount, onPageChange, label?, disabled?. Zero páginas não renderiza controles. Trunca contagens para inteiros e limita apresentação aos limites válidos. Callback não busca dados nem muda URL.
- `Stepper`: label?, steps:{id,title,description?,completed?,disabled?}[], currentId, onStepChange?. Sem callback é informativo; com callback, botões emitem etapa escolhida. Validação, bloqueio de avanço e painel da etapa são responsabilidade do produto. Só marque completed após confirmação.
- `useScrollSpy(ids, {rootId?,offset?})`: retorna ID ativo, usa scroll/resize com requestAnimationFrame, limpa listeners e não muda URL/foco. RootId deve identificar um contêiner rolável existente; omitido acompanha window. Elementos precisam ter IDs únicos e estar montados. Recrie a lista de IDs quando a estrutura mudar.
- `ScrollSpyNav`: items:{id,label}[], label, rootId?, offset? (100). Links apontam para IDs existentes e usam aria-current=location conforme rolagem. Conteúdo que muda de altura sem scroll/resize deve provocar recálculo via resize ou remontagem do índice.

## Expansão e abas

`Accordion`: label, items:{id,title,content,disabled?}[], multiple? (false), value?:string[], defaultValue?:string[], onValueChange?(ids). Mesmo em expansão única a API usa array, com zero ou um ID. Use estado controlado **ou** defaultValue. Múltiplo permite vários abertos. Enter/Espaço alternam, setas/Home/End percorrem títulos. Cada trigger é botão com aria-expanded e painel associado.

`Collapse`: label, children, open?, defaultOpen?, onOpenChange?. Painel oculto não permanece tabulável. Use para apoio secundário, nunca para esconder instruções necessárias ao preenchimento.

`Tabs`: label, items:{id,label,content,disabled?}[], value?, defaultValue?, onValueChange?, orientation?:horizontal|vertical. Ativação automática com setas; Home/End, Tab e nomes/IDs gerenciados por Radix. Conteúdo inativo é desmontado: estado local de formulários dentro de painéis deve ficar no consumidor para sobreviver à troca. Para navegar entre URLs, use Nav.

## Sobreposições

```tsx
const [open, setOpen] = useState(false);
<Dialog
  title="Revisar alterações"
  description="Confira antes de salvar."
  open={open}
  onOpenChange={setOpen}
  trigger={<Button variant="secondary">Revisar</Button>}
  footer={<Button onClick={save}>Salvar alterações</Button>}
>
  <Input label="Nome" value={name} onChange={(e) => setName(e.target.value)} />
</Dialog>;
```

`Dialog`: title, description, trigger:ReactElement, children, footer?, open?, defaultOpen?, onOpenChange?, closeLabel?. `Drawer` recebe as mesmas props + side?:left|right|bottom (right). Trigger deve aceitar ref e eventos (Button já aceita). Ambos são **modais**, com backdrop, bloqueio de scroll, nome/descrição, foco contido, Escape/fechamento externo e retorno ao trigger. Conteúdo desmonta ao fechar; mantenha rascunhos fora dele. Não implemente operação irreversível apenas pelo fechamento. Confirmação, persistência e recuperação são do produto.

`CloseButton`: atributos nativos de button, ref e aria-label (padrão “Fechar”). Usado nos fechamentos Radix e disponível para mensagens próprias. Não presume qual estado fechar.

`Popover`: title, trigger:ReactElement, children, open?, onOpenChange?. É uma região dialog **não modal**, com posicionamento e colisão na viewport. Pode conter links/ações. Fecha com Escape, botão ou interação externa; restaura foco ao trigger conforme Radix. `Tooltip`: content:string, children:ReactElement focável, sem controles internos. Tooltip é ajuda curta; informações essenciais precisam estar no texto visível.

## Notificações e carregamento

```tsx
<ToastProvider>
  <Button onClick={() => setToastOpen(true)}>Mostrar resultado</Button>
  <Toast
    open={toastOpen}
    onOpenChange={setToastOpen}
    title="Alterações salvas"
    description="Cadastro atualizado."
    duration={6000}
  />
</ToastProvider>
```

Use **um ToastProvider por aplicação** e mantenha um Toast por notificação controlada. Toast recebe title, description?, open, onOpenChange, duration? (6000ms). Há anúncio para tecnologia assistiva, botão de fechar, pausa durante foco/hover e acesso por F8 à viewport. Não substitua erros persistentes ou informação crítica por toast com timeout. Só abra sucesso após resposta confirmada da API; o catálogo é uma simulação rotulada.

`Spinner`: label?; role=status, ícone e texto. `Skeleton`: label?, lines? (3, limitado entre 1 e 10); representação estática para respeitar leitura e movimento reduzido. `Progress`: label, value?, max? (100); omitir value gera indeterminado; números fora do intervalo são limitados, max inválido volta a 100. O componente não estima progresso real.

`Carousel`: label, slides:{id,label,content}[]. Manual, finito, anterior/próximo e anúncio da posição. Slides inativos usam hidden e saem da árvore acessível/tabulação. Não inclui swipe, autoplay ou reprodução de mídia; não mantenha campos essenciais em slides. IDs devem ser estáveis. Zero slides mostra um estado vazio. Não aninhe carrosséis.

## Critérios para agentes SDD

1. Relacione requisito a componente, dados, estados e teste. A matriz acima é uma seleção de API, não uma especificação de negócio.
2. Defina fonte dos dados e callbacks: DataTable não ordena sozinho, Pagination não consulta API e Stepper não autoriza avanço.
3. Documente persistência de estado em conteúdo desmontável (Tabs, Dialog/Drawer). Fechar um painel não deve descartar rascunho sem regra explícita.
4. Valide foco no fluxo completo: abrir, percorrer, confirmar, erro, fechar e retornar. Teste sem mouse e em 320px.
5. Controle IDs, chaves, labels e fontes de mídia. Nenhum número do catálogo é métrica real; nenhuma opção demonstrativa é oferta.
6. Consulte COMPONENTS.md e SDD.md para formulários e regras compartilhadas. Homologue navegadores/leitores de tela nas tarefas reais do produto.
