# Sparkling Hub · Design system

Biblioteca React + TypeScript + Tailwind CSS para os SaaS da Sparkling Hub. Versão **0.2.0**, tema claro. O catálogo interativo demonstra componentes reais da biblioteca, com dados fictícios e sem persistência/API.

## Executar

Requer Node.js 22.12+ (validado com 24.18) e npm.

```powershell
cd C:\repos\sparklinghub.com.br\UX\design-system
npm ci
npm run dev
```

Abra o endereço impresso pelo Vite. `npm run build` gera **dist/** (biblioteca ESM + declarações TypeScript + CSS) e **catalog/** (catálogo estático). `npm run preview` serve o catálogo compilado. A biblioteca não precisa de um servidor próprio em produção.

## Consumir em outro SaaS

Gere um pacote com `npm run build` e `npm pack`. No projeto consumidor, instale o arquivo `sparkling-hub-design-system-0.2.0.tgz` produzido. Isso inclui dependências, documentação e licença do Tailblocks. O pacote é privado; publicação em registro não faz parte desta entrega. React e React DOM 19 são peer dependencies, fornecidos pelo aplicativo.

```tsx
import "@sparkling-hub/design-system/styles.css";
import { Input, Button } from "@sparkling-hub/design-system";

export function ContactForm() {
  return (
    <div className="sh-theme">
      <form onSubmit={(event) => event.preventDefault()}>
        <Input label="Nome" name="name" autoComplete="name" required />
        <Button type="submit">Salvar</Button>
      </form>
    </div>
  );
}
```

Esse trecho ilustra composição, não persistência. O aplicativo implementa validação, submissão, autorização e feedback conforme `docs/SDD.md`.

Importe o CSS **uma única vez**, na entrada da aplicação; mantenha a raiz da interface sob `.sh-theme`. O CSS distribuído já contém as utilidades usadas pela biblioteca e a fonte Manrope local. Não é necessário escanear o pacote com Tailwind nem acessar um CDN. Não há preflight global: os estilos de componentes são prefixados `sh-`; reset da aplicação permanece responsabilidade do consumidor. Tokens `--color-sh-*` são globais e as utilidades de layout geradas são classes Tailwind padrão. Havendo conflito com CSS existente, teste a ordem das camadas; prefira importar o DS antes dos estilos específicos do produto.

Em SSR/RSC, os componentes interativos precisam de fronteira cliente definida pelo consumidor (`'use client'`). O editor e `sanitizeRichText` são **browser-only**: renderize o editor após montagem ou via importação dinâmica sem SSR. Não chame o sanitizador do navegador em Node. As demais primitivas usam `useId` para IDs estáveis.

## O que está incluído

- Tokens: cores, tipografia, raios, espaçamento, foco, movimento e elevação.
- Input nativo (texto, e-mail, busca, telefone, URL, número, datas/horas, arquivo, cor e range), PasswordInput, Textarea, Select simples/múltiplo, Checkbox com estado parcial, RadioGroup.
- Button primário/secundário/discreto/destrutivo, loading e disabled; DropdownButton com Radix.
- RichTextEditor com Tiptap, formatação, títulos, listas, limpar formatação, desfazer/refazer e sanitização HTML.
- Alert, Badge, EmptyState; SettingsBlock, StatsBlock e StepsBlock adaptados do Tailblocks.
- Conteúdo editorial, prosa, imagens, figuras, citações, perfis, cards, tabelas e listas.
- Navegação, breadcrumbs, paginação, etapas, scrollspy, abas, accordion, modal, drawer, popover, tooltip, toast, carrossel e feedback de carregamento.
- Composições Tailblocks de abertura, conteúdo, recursos, galeria, equipe, comparação de opções, chamada e rodapé.
- Catálogo responsivo, exemplos de API, documentação SDD e testes.

Não inclui backend, máscaras financeiras, autocomplete remoto, upload efetivo, editor colaborativo, tema escuro nem componentes de agenda/tabela específicos. Inputs nativos de data, hora, arquivo e cor respeitam o navegador/SO. Requisitos futuros devem ampliar a biblioteca por especificação, mantendo a identidade compartilhada.

## Documentação para implementação

1. [Fundamentos e decisões](docs/FOUNDATIONS.md)
2. [Contratos dos componentes](docs/COMPONENTS.md)
3. [Fluxo SDD e critérios de aceite](docs/SDD.md)
4. [Template de especificação](docs/spec-template.md)
5. [Origem dos blocos Tailblocks](docs/TAILBLOCKS.md)
6. [Verificação e limites](docs/VALIDATION.md)
7. [Conteúdo, interações e correspondência Bootstrap](docs/CONTENT.md)

`AGENTS.md` contém as regras locais para agentes. `tokens.json` é o espelho legível por máquina; `src/styles.css` é a fonte executável. Ao alterar tokens, atualize ambos e documente a decisão.

## Verificar

```powershell
npm run typecheck
npm test
npm run build
npm run test:package
npm run test:e2e
npm audit
```

O teste E2E usa Microsoft Edge instalado (`channel: 'msedge'`) e inicia Vite na porta 5179. Para CI Linux, instale Chromium com Playwright e remova/substitua `channel` na configuração. As imagens são geradas em `test-results/`. Não há alegação de certificação de acessibilidade: homologação assistiva e em outros navegadores continua necessária em cada produto.

## Fontes

Identidade herdada de `../../DESIGN.md`, `../branding.md` e da logomarca aprovada em `../assets/logomarca/final-v1/`. O React substitui apenas a tecnologia dos protótipos institucionais para esta biblioteca, conforme o requisito dos SaaS. O site Astro existente não é alterado.

Tailblocks é distribuído sob MIT: fontes e licença preservadas em `vendor/tailblocks/`. Manrope vem de `@fontsource-variable/manrope` sob SIL OFL; preserve a licença da dependência na redistribuição. As dependências mantêm suas próprias licenças.
