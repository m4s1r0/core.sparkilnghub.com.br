# Changelog

## 0.2.0 — 2026-10-26

- Conteúdo: Heading, Text, Prose, Blockquote, DescriptionList, ResponsiveImage, Figure, Avatar, Card e DataTable tipada.
- Navegação: Breadcrumb, ButtonGroup, ToggleButton, Nav, NavOverflow, Navbar, Pagination, Stepper e ScrollSpyNav/useScrollSpy.
- Interações: Accordion, Collapse, Tabs, Dialog, Drawer, CloseButton, Popover, Tooltip, ToastProvider/Toast e Carousel.
- Feedback: ListGroup, Skeleton, Progress e Spinner.
- Composições Tailblocks: ContentSection, FeatureGrid, HeroBlock, CalloutBlock, Gallery, TeamGrid, PricingGrid e FooterBlock, com origem e fontes preservadas.
- Catálogo ampliado com demonstrações funcionais, imagens locais rotuladas e guia de correspondência Bootstrap/SDD.
- Mantida a API de formulários existente; novas APIs são aditivas.

## 0.1.0 — 2026-10-25

- Primeira biblioteca React/TypeScript/Tailwind da Sparkling Hub, baseada na identidade aprovada.
- Campos nativos, seleção, botões, menu, feedback e editor Tiptap com allowlist HTML.
- Três blocos Tailblocks adaptados, com fontes e licença preservadas.
- Catálogo interativo e documentação técnica/SDD.
- Testes de contratos de formulários, sanitização e jornadas de navegador.
