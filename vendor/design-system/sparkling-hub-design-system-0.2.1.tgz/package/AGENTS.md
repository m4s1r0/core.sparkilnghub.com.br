# Contrato para agentes de implementação

Escopo: este diretório e o consumo de `@sparkling-hub/design-system`.

1. Leia README.md, docs/FOUNDATIONS.md, docs/COMPONENTS.md e docs/SDD.md antes de implementar uma interface. O contrato visual de origem é ../../DESIGN.md. O pedido explícito do usuário prevalece sobre o stack Astro dos protótipos institucionais: aqui use React, TypeScript e Tailwind.
2. Importe componentes apenas pela API pública de src/index.ts (ou pelo nome do pacote no consumidor). Não copie estilos de controles para cada SaaS.
3. Mantenha uma única paleta. Não use lima em texto sobre branco nem como fundo de seção. Ações primárias são verde-azulado com texto branco. Logotipos são SVGs aprovados, nunca redesenhados.
4. Use os contratos nativos de formulários, labels visíveis, IDs únicos, refs e aria-describedby. Nunca troque um select por DropdownButton: seleção de valor e menu de ações têm semânticas distintas.
5. Especifique estados vazio, carregando, sucesso, erro, disabled, readOnly e conflito quando aplicáveis. Nenhum sucesso sem resposta confirmada da API.
6. Código de UI não implementa autorização, isolamento de instâncias, validação autoritativa ou persistência. Preserve o vínculo requisito → componente → teste.
7. Texto rico é entrada não confiável. Use a allowlist do editor e sanitização adicional no servidor. Não acrescente HTML livre, imagens, links ou embeds sem especificação e testes.
8. Mudanças públicas exigem docs, changelog e versão. Durante 0.x, alterações incompatíveis incrementam minor; correções compatíveis incrementam patch. Não publique pacotes automaticamente.
9. Verifique tipos, testes afetados, build e teclado/viewport quando alterar comportamento ou layout. Use o Edge local para E2E; documente limitações. Não alegue conformidade WCAG apenas por axe.
10. Preserve vendor/tailblocks como registro upstream. Novas adaptações devem registrar caminho e SHA em docs/TAILBLOCKS.md e manter a licença MIT.
11. Para conteúdo, tabelas, navegação e sobreposições, leia docs/CONTENT.md. Respeite os contratos controlados de dados e estado, as semânticas de teclado/foco e a preservação de rascunhos em painéis desmontáveis. A referência Bootstrap não introduz dependência de CSS/JS Bootstrap no produto.
12. Movimento segue docs/MOTION.md e tokens.json. Preserve foco imediato, reversão e redução de movimento inclusive nos portais. Não anime a página inteira nem vincule persistência a animationend; Collapse fechado permanece inert/aria-hidden. Use os componentes compartilhados para evitar estilos divergentes por SaaS.
