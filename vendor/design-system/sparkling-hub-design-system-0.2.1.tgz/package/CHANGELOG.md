# Changelog

## 0.2.1 — 2026-10-26

- Revisão Impeccable com hierarquia editorial, superfícies de demonstração e navegação agrupada; assinatura inversa aprovada na abertura.
- Indicador de abas contínuo, expansão de Accordion/Collapse e entrada/saída de Dialog, Drawer, menus, Popover, Tooltip e Toast.
- Tokens de movimento de 120/160/220ms, easing de saída e níveis de sobreposição; redução de movimento cobre o backdrop e as raízes temáticas de portal.
- Collapse aplica inert/aria-hidden ao fechar, mantendo conteúdo e estado montados durante a transição.
- Navegação móvel do catálogo passa a usar o Drawer compartilhado, com foco contido, Escape e restauração de foco.
- Amostras de cor copiáveis, código copiável compartilhado, ícones consistentes e prévia interativa de movimento reduzido.
- API pública preservada; documentação, guia SDD, evidências e pacote de distribuição atualizados.

## 0.2.0 — 2026-10-26

- Conteúdo: Heading, Text, Prose, Blockquote, DescriptionList, ResponsiveImage, Figure, Avatar, Card e DataTable tipada.
- Navegação: Breadcrumb, ButtonGroup, ToggleButton, Nav, NavOverflow, Navbar, Pagination, Stepper e ScrollSpyNav/useScrollSpy.
- Interações: Accordion, Collapse, Tabs, Dialog, Drawer, CloseButton, Popover, Tooltip, ToastProvider/Toast e Carousel.
- Feedback: ListGroup, Skeleton, Progress e Spinner.
- Composições Tailblocks: ContentSection, FeatureGrid, HeroBlock, CalloutBlock, Gallery, TeamGrid, PricingGrid e FooterBlock, com origem e fontes preservadas.
- Catálogo ampliado com demonstrações funcionais, imagens locais rotuladas e guia de correspondência Bootstrap/SDD.
- Mantida a API de formulários existente; novas APIs são aditivas.

## 0.1.0 — 2026-10-25

- Primeira biblioteca React/TypeScript/Tailwind da Sparkling Hub, baseada na identidade aprovada.
- Campos nativos, seleção, botões, menu, feedback e editor Tiptap com allowlist HTML.
- Três blocos Tailblocks adaptados, com fontes e licença preservadas.
- Catálogo interativo e documentação técnica/SDD.
- Testes de contratos de formulários, sanitização e jornadas de navegador.
