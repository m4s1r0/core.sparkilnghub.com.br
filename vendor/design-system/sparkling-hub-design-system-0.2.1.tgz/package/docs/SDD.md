# Implementação orientada por especificações

Este documento é o contrato para agentes de SDD (Spec-Driven Development). O design system define apresentação e interação; as especificações de produto definem regras de negócio, autorização, dados e persistência. Leia também os escopos compartilhados em `../../../docs/escopos/`.

Para selecionar componentes de conteúdo, tabelas, navegação e sobreposições, use a matriz e os contratos de [CONTENT.md](CONTENT.md). Especifique especialmente quem ordena/pagina os dados, quando o estado de abas/modais é preservado e para onde o foco retorna ao fechar uma sobreposição.

Movimento e camadas seguem [MOTION.md](MOTION.md). Não vincule persistência a animationend, não atrase foco por efeito visual e verifique o mesmo fluxo com movimento reduzido. No Collapse, o conteúdo fechado continua montado mas está inert/aria-hidden durante a saída.

## Ordem de trabalho

1. **Spec:** identifique requisito, persona, tarefa, entrada/saída, permissões, estados e critérios observáveis. Use spec-template.md. Não trate a aparência do catálogo como requisito de negócio.
2. **Plan:** mapeie cada campo para componente público. Defina estado controlado/não controlado, valores vazios, validação, foco, contrato de API e tratamento de conflito. Registre qualquer lacuna do DS antes de criar componente local.
3. **Tasks:** decomponha por fluxo verificável: carregar → editar → validar → enviar → confirmar/recuperar. Dê a cada tarefa requisito e teste correspondentes.
4. **Implement:** use imports públicos; estilos estruturais por Tailwind; tokens semânticos para cores. Não copie CSS de controles nem implemente novo dropdown com divs.
5. **Verify:** comprove critérios da spec por testes de interação e evidência visual quando pertinente. Tipos, build e testes devem passar. Uma tela bonita não demonstra persistência ou autorização.

## Matriz de estados obrigatória

| Estado               | Comportamento esperado                                                              | Evidência                                          |
| -------------------- | ----------------------------------------------------------------------------------- | -------------------------------------------------- |
| Inicial              | Labels e instruções, valores corretos, uma ação principal                           | Inspeção/consulta dos elementos por nome acessível |
| Vazio                | Motivo e próxima ação; distinguir filtro sem resultado de lista vazia               | Teste com dados vazios e filtro                    |
| Carregando           | Texto claro, região aria-busy quando apropriado, nenhuma falsa contagem zero        | Resposta atrasada simulada                         |
| Inválido             | Erro por campo, resumo focado, dados preservados                                    | Submissão inválida com teclado                     |
| Enviando             | Button loading, prevenir clique duplicado; idempotência quando exigida pelo backend | Duplo clique/timeout                               |
| Sucesso              | Só após confirmação da API; status anunciado e resultado atual                      | Teste de resposta confirmada                       |
| Erro de rede/API     | Mensagem segura, reenvio quando permitido, valores preservados                      | Rejeição/timeout                                   |
| Conflito             | Avisar concorrência, permitir revisão sem apagar alterações silenciosamente         | Resposta de versão obsoleta                        |
| Sem permissão        | Sem ação indevida; servidor revalida toda operação                                  | Testes positivos e negativos de API                |
| Desabilitado/leitura | Motivo visível; sem perda involuntária de dado no payload                           | FormData/payload e teclado                         |

Estados sem aplicação devem ser marcados como tal com motivo. Nunca use o erro visual como única validação de segurança.

## Exemplo de mapeamento de requisito

Requisito ilustrativo DS-EX-001: cadastrar contato com nome e e-mail. Campos: Input name e Input type=email; ajuda e erro sob os campos; Button submit com loading; Alert de resultado. Escolhas exclusivas: RadioGroup; enum longo: Select; preferências independentes: Checkbox; ações adicionais: DropdownButton. Anotações simples: Textarea; conteúdo formatado: RichTextEditor.

Critérios: submissão inválida não chama API; resumo recebe foco; links do resumo focalizam os controles; API com sucesso confirma e atualiza lista; erro preserva valores; tabulação segue a ordem visual; 320/360px sem rolagem horizontal da página; redimensionamento e zoom não escondem a ação.

## Regras para dados e formulários

- `name` estável no contrato; label em português, separado do identificador técnico. Nunca derive autorização de name, hidden input, query string ou estado React.
- Campo obrigatório inclui required nativo e validação do domínio/servidor. Em formulários noValidate, a aplicação é responsável por validar e anunciar erros; não copie noValidate sem implementar o fluxo.
- Não mude máscara enquanto o usuário digita sem preservar cursor/seleção. Não aplique uma regex universal para todos os telefones, nomes ou documentos.
- Senhas usam autoComplete adequado (current-password/new-password), sem logs ou armazenamento local.
- Não use os números fictícios do catálogo como valores reais, metas, métricas comerciais ou defaults de produção.
- Dinheiro: centavos inteiros no contrato. Datas civis não são instantes UTC; datetime-local não carrega fuso. A especificação deve dizer como converter.
- HTML do editor: allowlist documentada, limite de tamanho e sanitização server-side. Não use dangerouslySetInnerHTML em resposta arbitrária. Para extrair “vazio”, considere texto sem tags/espaços e sem caracteres invisíveis, não o comprimento do HTML.
- Arquivo: accept é dica de seleção, não validação. Servidor verifica conteúdo, tamanho, permissão e destino.
- Sucesso não é timer local. O timer do catálogo é uma simulação rotulada; substitua-o por resposta real no produto.

## Contrato visual entre SaaS

Envolva a interface em sh-theme; importe styles.css uma vez. Construa layout com classes Tailwind estáticas. Não crie classes interpoladas como `bg-${color}-500` nem presuma que Tailwind detecta strings dinâmicas. As utilidades da biblioteca já estão compiladas. As novas utilidades do consumidor devem estar nos próprios arquivos rastreados pelo seu Tailwind.

Não redefina cores por produto. Não retire foco para combinar com mockup. Não faça botão/link sem nome acessível. Ícones lucide ou SVGs de linha consistentes: 24x24, stroke 1.75; ícones decorativos aria-hidden. Texto de ação diz o resultado (“Salvar contato”), não apenas “OK”.

## Extensão e governança

Antes de criar algo novo, verifique componentes, blocos e limitações em COMPONENTS.md. Se a lacuna for compartilhada, crie proposta de componente com API, estados, teclado, contratos de dados e testes. Se for regra de domínio (ex.: agenda de banho e tosa), mantenha no SaaS e componha as primitivas.

Mudança de API pública exige atualização de docs, declarações, catálogo, testes e CHANGELOG.md. Durante 0.x, alteração incompatível incrementa minor. Atualize tokens.json junto com CSS. O consumidor deve fixar uma versão testada; não compartilhar cópias editadas manualmente.

## Checklist de entrega do agente

- Requisitos, componentes, decisões e testes rastreáveis.
- Tipos e build passam; nenhum console error novo.
- Nomes acessíveis, Tab/Shift+Tab, setas em radio/select/menu, Escape e restauração do foco.
- Erros textuais com associação e foco; loading e resultado anunciados sem duplicação desnecessária.
- 320px, desktop, zoom, strings longas, valores ausentes, reduced motion.
- Sem dados reais/sensíveis nas fixtures, screenshots ou logs.
- Testes de negócio/API no produto; testes do DS não substituem autorização/isolamento/idempotência.
- Evidência e limites registrados, sem declarar homologação de navegador/leitor de tela não testado.
