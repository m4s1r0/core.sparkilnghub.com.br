# Proveniência Tailblocks

Repositório: https://github.com/mertJF/tailblocks

Revisão consultada e preservada: `34943e63da6a2d45a55a076ea18312a1c1098957`. Licença MIT original: `vendor/tailblocks/LICENSE`, copyright 2020 Mert Cukuren. Os arquivos originais foram baixados dessa revisão, não da branch mutável durante o build.

| Original no repositório         | Cópia local intacta            | Adaptação em src/blocks.tsx                                                                                                                             |
| ------------------------------- | ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| src/blocks/contact/light/b.js   | vendor/tailblocks/contact.js   | SettingsBlock: preserva composição responsiva de contexto e formulário; remove mapa/contatos fictícios, substitui por descrição/aside e slots de campos |
| src/blocks/statistic/light/a.js | vendor/tailblocks/statistic.js | StatsBlock: preserva coleção responsiva de indicadores; usa dl/dt/dd, dados por props e tokens semânticos                                               |
| src/blocks/step/light/a.js      | vendor/tailblocks/step.js      | StepsBlock: preserva trilha vertical com marcadores e explicações; usa ol/li, aria-current e current controlado pelo consumidor, remove imagem dummy    |

Fontes diretas: [Contact B](https://github.com/mertJF/tailblocks/blob/34943e63da6a2d45a55a076ea18312a1c1098957/src/blocks/contact/light/b.js), [Statistic A](https://github.com/mertJF/tailblocks/blob/34943e63da6a2d45a55a076ea18312a1c1098957/src/blocks/statistic/light/a.js), [Step A](https://github.com/mertJF/tailblocks/blob/34943e63da6a2d45a55a076ea18312a1c1098957/src/blocks/step/light/a.js).

Tailblocks fornece blocos para copiar e adaptar, não uma dependência npm de componentes. As adaptações são locais, TypeScript, com utilidades Tailwind e tokens da Sparkling Hub. Classes dinâmicas de paleta foram retiradas; controles foram substituídos pelas primitivas compartilhadas. As fontes vendor são documentação, não são importadas na aplicação nem executadas. Atualizações upstream exigem revisão explícita, comparação e atualização deste registro.

Não se atribui ao Tailblocks o editor WYSIWYG, RadioGroup, Checkbox nem DropdownButton: esses componentes foram implementados neste pacote; menu usa Radix e editor usa Tiptap.

## Ampliação de conteúdo — 0.2.0

As fontes adicionais também vêm da revisão `34943e63da6a2d45a55a076ea18312a1c1098957` e permanecem intactas em vendor/tailblocks. Os componentes adaptados estão em src/content.tsx e src/navigation.tsx.

| Original (`src/blocks/…`) | Arquivo preservado | Adaptação                                                                                                           |
| ------------------------- | ------------------ | ------------------------------------------------------------------------------------------------------------------- |
| content/light/a.js        | content-a.js       | ContentSection: título, descrição e área de conteúdo; remove rótulo promocional e bordas decorativas fortes         |
| blog/light/a.js           | blog-a.js          | Card: composição mídia/corpo/rodapé; remove categorias e métricas fictícias, usa slots e heading semântico          |
| gallery/light/a.js        | gallery-a.js       | Gallery/Figure: agrupamento responsivo de imagens; acrescenta alt/legendas por item e simplifica para grade legível |
| feature/light/a.js        | feature-a.js       | FeatureGrid: ícone de linha + título + texto/link; tokens da marca e fios finos                                     |
| hero/light/a.js           | hero-a.js          | HeroBlock: texto/ações e mídia lado a lado, empilhados em telas pequenas                                            |
| cta/light/a.js            | cta-a.js           | CalloutBlock: chamada e ação com quebra responsiva                                                                  |
| testimonial/light/a.js    | testimonial-a.js   | Blockquote: citação com autoria/fonte fornecida; sem inventar depoimentos                                           |
| team/light/a.js           | team-a.js          | TeamGrid/Avatar: perfil, responsabilidade e descrição; imagem opcional com fallback                                 |
| pricing/light/a.js        | pricing-a.js       | PricingGrid: comparação com preço/descrição/recursos/ação fornecidos pelo produto                                   |
| header/light/a.js         | header-a.js        | Navbar: marca, navegação e ação; acrescenta disclosure e consulta de contêiner                                      |
| footer/light/a.js         | footer-a.js        | FooterBlock: marca/contexto, grupos de links e linha final                                                          |

URL de origem de cada linha: `https://github.com/mertJF/tailblocks/blob/34943e63da6a2d45a55a076ea18312a1c1098957/src/blocks/<caminho-original>`.

Typography/Prose, DataTable, Accordion, Tabs, Dialog/Drawer, Popover, Tooltip, Toast, Pagination, ScrollSpy e os demais comportamentos são implementações próprias sob os tokens e a linguagem dessas composições. Tailblocks não oferece equivalentes interativos completos para todos os componentes do Bootstrap. A correspondência funcional e as fontes oficiais do Bootstrap estão em [CONTENT.md](CONTENT.md). Não se atribui ao Tailblocks código de foco/teclado fornecido pelo Radix nem se instala Bootstrap como runtime.

As três imagens locais em public/examples foram reutilizadas do acervo ilustrativo de UX/webdesign/site/public/img, preservando as legendas de ilustração. São fixtures do catálogo, não parte dos dados ou dos assets obrigatórios do pacote consumidor.

## Refinamento 0.2.1

A revisão Impeccable aprimora apresentação, tokens e transições sem modificar os arquivos upstream preservados nem trocar a revisão de origem. A assinatura inversa usada na abertura vem do mesmo acervo aprovado em UX/assets/logomarca/final-v1. Os estilos de movimento são locais, descritos em [MOTION.md](MOTION.md), e não são atribuídos ao Tailblocks ou ao Bootstrap.
