# Movimento e refinamento visual — 0.2.1

Revisão realizada com a skill Impeccable em 26/10/2026. O conceito “A Centelha Organizada”, a paleta aprovada, Manrope, o SVG da marca e os contratos de componentes foram preservados. Esta revisão aperfeiçoa a biblioteca e seu catálogo.

## O que mudou visualmente

- O catálogo separa títulos de seção, contexto, metadados de API, superfícies de exemplo e código. A leitura deixa de depender apenas de sucessivos fios na mesma superfície.
- Os exemplos de conteúdo usam um campo branco plano com fios horizontais; não recebem sombras de cartões. A sombra continua reservada às sobreposições.
- A abertura usa a assinatura inversa aprovada sobre petróleo. O restante da página mantém predominância de névoa/branco. A versão completa continua com mínimo de 240px.
- A navegação foi agrupada em Sistema, Componentes e Implementação. Em celular utiliza o Drawer existente com foco contido, Escape, backdrop e retorno ao botão de abertura.
- As amostras de cor e os exemplos de código podem ser copiados, com mensagem acessível de sucesso/falha.
- Metadados e instruções ganharam tamanhos mais legíveis. Ícones Lucide seguem traço de 1.75 dentro do tema.

Essas composições pertencem ao catálogo de documentação, em modo **Read**. A biblioteca atende interfaces de operação, em modo **Operate**. Os produtos não devem copiar a página inteira como um template obrigatório.

## Tese de movimento

**A seleção percorre; o conteúdo expande; uma camada preserva sua origem.** A sequência de autoria é o indicador de abas, que torna a relação entre a seleção anterior e a atual legível. Controles reconhecem a ação com feedback breve; conteúdo e camadas mudam de estado sem coreografia de entrada da página.

Não há parallax, revelações por scroll, autoplay, animação contínua de skeletons ou efeito de levantar todo card. O spinner já existente continua reservado a carregamento e mantém texto quando o movimento é reduzido.

## Tokens públicos

Os valores executáveis ficam em `src/styles.css`; a política de transições fica em `src/motion.css`. `tokens.json` espelha os valores para agentes e outras ferramentas.

| CSS                    | JSON              | Valor                    | Aplicação                                                   |
| ---------------------- | ----------------- | ------------------------ | ----------------------------------------------------------- |
| `--sh-motion-fast`     | motion.fastMs     | 120ms                    | Cores de controles, feedback de pressão, tooltip            |
| `--sh-motion-content`  | motion.contentMs  | 160ms                    | Mudança de conteúdo, menus/popovers, backdrop               |
| `--sh-motion-duration` | motion.durationMs | 220ms                    | Indicador de abas, expansão, entrada de Dialog/Drawer/Toast |
| `--sh-motion-exit`     | motion.exitMs     | 160ms                    | Recolhimento e saída de camadas                             |
| `--sh-ease`            | motion.easing     | cubic-bezier(.16,1,.3,1) | Continuidade/entrada, desacelerando até o estado final      |
| `--sh-ease-exit`       | motion.exitEasing | cubic-bezier(.4,0,1,1)   | Saída breve                                                 |

O token `--sh-motion-duration` existente continua válido. Os tokens adicionais são compatíveis com a versão anterior. Foco/outline não têm atraso nem interpolação: o sinal de teclado aparece imediatamente.

## Contratos por componente

| Componente             | Movimento                                                                | Preservação de interação                                                                                               |
| ---------------------- | ------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------- |
| Button                 | Cor/borda e 1px de pressão                                               | Sem movimento quando disabled; tamanho e foco preservados                                                              |
| Input e controles      | Mudança de borda/cor                                                     | Erro e foco permanecem explícitos; sem mover o campo                                                                   |
| Tabs                   | Indicador único acompanha posição e dimensões; conteúdo aparece em 160ms | Semântica/teclado Radix; estado ativo acessível independe do indicador                                                 |
| Accordion              | Altura local usa a medida fornecida pelo Radix                           | Expansão única/múltipla e foco continuam sob Radix                                                                     |
| Collapse               | Grid passa de 0fr a 1fr e recolhe                                        | Ao fechar aplica `inert` e `aria-hidden` imediatamente; conteúdo continua montado e não fica tabulável durante a saída |
| Dialog                 | Entrada breve com opacidade e ajuste discreto de posição/escala          | Foco contido, backdrop e retorno ao trigger; Radix coordena a desmontagem após a animação de saída                     |
| Drawer                 | Deslocamento de até 24px a partir do lado correspondente                 | Mesmo contrato modal do Dialog; não atravessa a tela inteira                                                           |
| DropdownButton/Popover | Aparecimento contextual com até 4px                                      | Escape, posicionamento e foco continuam gerenciados pelas primitivas                                                   |
| Tooltip                | Opacidade breve                                                          | Mantém conteúdo textual associado e fechamento por Escape                                                              |
| Toast                  | Entrada lateral discreta; saída/gesto coerente                           | Anúncio, pausa, tempo de leitura e fechamento continuam ativos                                                         |
| Carousel               | Troca breve de opacidade                                                 | Sem autoplay; apenas slide ativo fica acessível                                                                        |
| Alert                  | Entrada de opacidade                                                     | Texto/role continuam disponíveis, sem deslocar o usuário                                                               |
| Card com ação          | Transição apenas de borda no hover de ponteiro fino                      | Não transforma o card inteiro em botão e não adiciona elevação                                                         |

`Collapse` preserva seu estado controlado ou interno e o conteúdo montado, como antes. A ocultação agora combina grid, inert e aria-hidden em vez do atributo hidden para permitir a saída animada. Não dependa de seletores de implementação para definir regras de negócio.

O indicador de `Tabs` mede apenas a aba ativa e sua lista quando seleção, tamanho ou orientação requerem atualização. ResizeObserver observa dimensões; MutationObserver observa data-state. As leituras são agrupadas com requestAnimationFrame e os observers/listeners são descartados ao desmontar. Não existe um loop de animação contínuo. A seleção também possui representação visual sem JavaScript de medição.

## Movimento reduzido

`prefers-reduced-motion: reduce` remove transições, keyframes e rolagem suave, inclusive no backdrop que está fora de `.sh-theme`. Os estados finais, texto, foco e ações permanecem funcionais. O indicador de abas salta diretamente à nova posição; painéis e camadas abrem/fecham imediatamente.

A seção “Movimento” do catálogo permite simular redução **somente naquela prévia**. Esse controle não muda a preferência do dispositivo nem implementa uma configuração global dos SaaS. O produto pode oferecer sua própria configuração, mas deverá propagá-la também aos portais se a especificar.

## Camadas

| Token CSS         | Valor | Papel               |
| ----------------- | ----- | ------------------- |
| `--sh-z-overlay`  | 50    | Menu contextual     |
| `--sh-z-backdrop` | 70    | Fundo modal         |
| `--sh-z-dialog`   | 71    | Dialog/Drawer       |
| `--sh-z-popover`  | 80    | Conteúdo contextual |
| `--sh-z-tooltip`  | 90    | Ajuda curta         |
| `--sh-z-toast`    | 100   | Notificações        |

O backdrop tem fallbacks porque está fora do nó temático do portal. Personalizações locais de tema no ancestral do aplicativo não atravessam portais automaticamente; configurações globais devem ser aplicadas também às raízes temáticas de portal. Não acrescente números arbitrários de z-index em cada produto.

## Uso por agentes SDD

1. Escolha movimento pela mudança de estado, nunca apenas porque um elemento está na tela.
2. Reutilize os componentes e tokens existentes. O CSS de movimento já está incluído no styles.css distribuído; não instale uma biblioteca de animação para reproduzir estes efeitos.
3. Não atrase validação, autorização, confirmação da API ou foco para “terminar a animação”. Loading não deve ser sucesso antecipado.
4. Em conteúdo recolhido, mantenha a barreira de interação durante toda a saída. Não retire inert/aria-hidden para animar.
5. Não acople persistência a animationend: movimento reduzido elimina esse evento. As regras de negócio devem funcionar independentemente dos keyframes.
6. Teste reversão rápida, troca por teclado, redimensionamento, portal, redução de movimento e desmonte de componentes. O estado selecionado precisa continuar correto mesmo se uma animação for interrompida.
7. Registre exceções com propósito, custo, duração, easing, redução e evidência. As APIs de formulário/conteúdo e a correspondência com Bootstrap continuam descritas em COMPONENTS.md e CONTENT.md.

## Evidências e limites

`tests/motion.spec.ts` verifica alinhamento após troca rápida de abas, simulação local, redução no indicador e no backdrop/Dialog, foco da navegação móvel e largura da página em 320, 768, 1024 e 1440px. Os testes de conteúdo existentes verificam foco, Escape, ordenação, paginação e carregamento. A verificação assistiva com leitores de tela e outros navegadores continua sendo parte da homologação dos produtos; os resultados executados ficam em VALIDATION.md.
