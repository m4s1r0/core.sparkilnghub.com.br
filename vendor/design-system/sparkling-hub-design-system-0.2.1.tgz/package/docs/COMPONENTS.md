# API pública e contratos

Importação pública: `@sparkling-hub/design-system`. Tipos são emitidos em `dist/*.d.ts`; exports em `src/index.ts`. Componentes ficam sob `.sh-theme`. O menu usa portal próprio com a mesma classe para manter tokens e tipografia.

Conteúdo editorial, imagens, tabelas, navegação, composições e componentes interativos adicionados em 0.2.0 estão documentados em [CONTENT.md](CONTENT.md), incluindo a correspondência com Bootstrap e os contratos para agentes SDD.

Na revisão 0.2.1, transições e refinamentos visuais mantêm a API pública. O comportamento de movimento, camadas e redução está em [MOTION.md](MOTION.md); importar styles.css já inclui essa política. Buttons reconhecem pressão, foco dos controles aparece imediatamente e ícones usam traço consistente.

## Campos nativos

`Input`, `PasswordInput`, `Textarea`, `Select` e `Checkbox` recebem `label: string`, `hint?: string`, `error?: string` e os atributos nativos do elemento correspondente. Encaminham ref ao controle. `id` é opcional; sem ele é gerado por useId. `name` é necessário para FormData. `value/onChange` e `defaultValue` seguem React: não misture estado controlado e não controlado. Checkbox usa `checked/onChange` ou `defaultChecked`.

| Componente    | Propriedades específicas                                                             | Contrato                                                                                                                                                         |
| ------------- | ------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Input         | `type`, `inputMode`, `min`, `max`, `step`, `pattern`, `autoComplete`, `accept`, etc. | Elemento input nativo; texto/e-mail/password/tel/url/search/number/date/time/datetime-local/month/week/file/color/range. Hidden deve usar HTML nativo sem Field. |
| PasswordInput | Atributos de Input, exceto `type`                                                    | Botão mostrar/ocultar, aria-pressed; não altera valor nem submete formulário.                                                                                    |
| Textarea      | `rows`, `maxLength`                                                                  | Quatro linhas por padrão; resize vertical. Não há contador implícito.                                                                                            |
| Select        | `options: {value,label,disabled?}[]`, `placeholder?`, `multiple?`                    | Select nativo, teclado e interação do SO. Placeholder tem valor vazio; use required se obrigatório. Múltiplo aceita array em value/defaultValue.                 |
| Checkbox      | `indeterminate?`                                                                     | Estado parcial via propriedade nativa; consumidor calcula checked/indeterminate. Estado misto não significa que todos os itens estejam selecionados.             |

`error` gera aria-invalid e inclui sua mensagem no aria-describedby. `hint` é associado sem substituir descrições externas. O texto da mensagem não é anunciado como alert em cada render; apresente um resumo de erros após tentativa de submissão e mova o foco até ele. O catálogo demonstra esse fluxo. Asterisco marca required visualmente; explique seu significado no formulário. Para campos opcionais, informe quando isso evitar dúvidas.

`disabled` retira o controle da submissão nativa e da navegação por Tab; `readOnly` mantém leitura e valor quando o elemento suporta esse atributo. Select/checkbox/radio não têm readOnly nativo: apresente um resumo textual se necessário, ou disabled acompanhado de instrução. Nunca envie valores ocultos como prova de permissão.

Input `number` não resolve moeda: contratos financeiros usam centavos inteiros; parser e apresentação são responsabilidade do produto. Input `datetime-local` não inclui fuso; converta com o fuso do estabelecimento, distinguindo data civil de instante. Input `file` apenas seleciona arquivos; validação, progresso, upload e autorização são responsabilidade da aplicação.

## RadioGroup

Props: `label`, `name`, `options: {value,label,disabled?}[]`, `value?`, `defaultValue?`, `onValueChange?(value)`, `disabled?`, `required?`, `hint?`, `error?`.

Usa fieldset/legend e radios nativos de mesmo name. Setas alternam as escolhas conforme o navegador; Tab entra/sai do grupo. Names devem ser únicos entre grupos independentes. Use para poucas opções mutuamente exclusivas. `onValueChange` entrega string, não evento.

## Ações

`Button`: atributos nativos de button + `variant: 'primary' | 'secondary' | 'ghost' | 'danger'` (primary padrão), `loading?: boolean`. Tipo padrão **button** para evitar submissões acidentais. Use `type="submit"` explicitamente. `loading` desabilita o botão e expõe aria-busy; passe texto apropriado como “Salvando…”. Não implementa idempotência de servidor. Para navegação, use link, nunca onClick que imita um href.

`DropdownButton`: `label`, `disabled?`, `variant?`, `items: {id,label,onSelect,disabled?,destructive?}[]`. Cada callback é uma ação do aplicativo. Radix implementa foco, setas, Home/End, busca por caracteres, Escape, fechamento externo e restauração do foco. Não é select, não armazena valor de formulário. `destructive` altera aparência; confirmação e autorização ficam no produto.

## RichTextEditor

Props: `label`, `value: string`, `onChange(html: string)`, `id?`, `name?`, `hint?`, `error?`, `disabled?`, `readOnly?`. **Controlado**, browser-only. Alteração externa de value sincroniza o conteúdo sem reemitir onChange; normalizações estruturais do Tiptap podem mudar o HTML equivalente. Troca de registro deve preferir `key={recordId}` para reiniciar histórico. `name` acrescenta input hidden com HTML sanitizado; disabled remove esse input da submissão.

Comandos: negrito, itálico, título h2, listas, limpar formatação, undo/redo. Atalhos nativos do Tiptap para formatação e histórico. Toolbar é um grupo de botões comuns acessível por Tab, sem declarar um padrão ARIA toolbar que exigiria navegação roving adicional. Estado ativo usa aria-pressed. Editor tem role=textbox, aria-multiline, label e descrição. Disabled bloqueia edição/comandos; readOnly permite ler/copiar e bloqueia comandos. Não possui required nativo: o consumidor deve validar conteúdo textual sem contar tags ou `<p></p>` como preenchimento.

`sanitizeRichText(html)` utiliza DOMPurify no navegador e preserva somente p, br, strong, em, s, u, h2, h3, ul, ol, li, blockquote, code, pre, hr, sem atributos. Links, imagens, estilos, scripts e embeds são removidos. HTML de entrada, saída, colagem e input hidden passa pela política. O editor não é um visualizador seguro universal: conteúdo de API deve ser sanitizado novamente no servidor antes de persistir/renderizar. Estabeleça tamanho máximo no contrato da API; o DS não fixa limites de negócio. A biblioteca não inclui links/upload/tabelas/colaboração.

## Feedback e composição

| Componente    | API                                                                      | Uso                                                                                                                                                              |
| ------------- | ------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Alert         | `title`, `tone?: info/success/warning/error`, children, atributos de div | role=alert para erro, status nos demais. Pode sobrescrever role; para mensagem estática que não deve ser live use role=note.                                     |
| Badge         | children, `tone?: neutral/success/warning/error`                         | Rótulo textual de estado, sem interação.                                                                                                                         |
| EmptyState    | title, description, action?                                              | Ausência de dados com próxima ação. Distinguir filtro vazio de falha da API.                                                                                     |
| SettingsBlock | title, description, children, aside?                                     | Grupo contextual com descrição lateral e campos. Não cria form nem submit.                                                                                       |
| StatsBlock    | label, `items: {label,value,detail?}[]`                                  | Lista de métricas já formatadas, sem agregação ou consulta. Labels únicos por lista.                                                                             |
| StepsBlock    | current, `steps: {title,description}[]`                                  | Lista informativa, current zero-based, aria-current=step. Títulos únicos, current entre 0 e length-1. Não é navegação nem wizard; aplicativo controla progresso. |

Componentes não acessam APIs, localStorage ou dados de sessão. Mensagens no catálogo são explicitamente demonstrativas. Integrações e extensões devem seguir docs/SDD.md.
